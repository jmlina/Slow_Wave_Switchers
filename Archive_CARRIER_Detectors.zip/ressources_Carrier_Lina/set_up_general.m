function OPTIONS = set_up_general(OPTIONS)

% set-up of the detectors

% SSW %%%%% Parameters (a priori, not to be changed) %%%%%%%%%%%%%%
OPTIONS.Sleep.SSW.method = 'Carrier016_4';  % can be Molle
OPTIONS.Sleep.SSW.Carrier.fmin_max          = [0.16 4]; % Hz
OPTIONS.Sleep.SSW.Carrier.duree_min_max_Neg = [125 1500]; % msec
OPTIONS.Sleep.SSW.Carrier.duree_max_Pos     = 1000; % msec
OPTIONS.Sleep.SSW.Carrier.PaP               = 75; % uV
OPTIONS.Sleep.SSW.Carrier.Neg               = 40; % uV
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% EEG SPINDLES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
OPTIONS.Sleep.SPL.method = 'Walker';
OPTIONS.Sleep.SPL.fmin_max      = [10 16]; % Hz
OPTIONS.Sleep.SPL.duree_min_max = [500 3000]; % msec
OPTIONS.Sleep.SPL.percentile    = 75; % in %
OPTIONS.Sleep.SPL.smoothing     = 200;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

