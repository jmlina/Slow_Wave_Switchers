clear
clc
addpath(genpath('./ressources_Carrier_Lina'));

fprintf('\n\n ========= SSW - Spindles project (%s) ========= \n\n',date);
fprintf('\tJ. Carrier, JM Lina, CEAMS (MONTREAL)\n\n');

% Data
load('./Data_exemple.mat')
fprintf('This ''fake EEG data'' is two ''recordings'' of the same\n');
fprintf('length (30 seconds @ 256Hz). The data are organized as follows:\n');
fprintf('\tfake_EEG.data is a matrix epochs x time\n');
fprintf('\tfake_EEG.fs is the sample frequency\n');
fprintf('\tfake_EEG.time is the time array.\n\n\n');


% This function defines the main parameters of the detectors %%%%
OPTIONS = struct;
OPTIONS = set_up_general(OPTIONS);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
% SSW detection %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [SSW] = detect_SSW_Carrier(fake_EEG,OPTIONS);
    fprintf(SSW.Comments); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
% Spindles detection %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    [Spindles] = detect_spindles_Walker(fake_EEG,OPTIONS);
    fprintf(Spindles.Comments);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
u = toc;
fprintf('\n----- done (%d msec). Bye\n\n',round(u*1000));



%%%%%%%%%%%%%%%%%%%%%%%%% FACULTATIVE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Vizualisation (first epoch) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
epo = 1;
figure('position',[100 100 1200 400]); 
    subplot(2,1,1); plot(fake_EEG.time, fake_EEG.data(epo,:));
    subplot(2,1,2); plot(fake_EEG.time, SSW.filtered_signals(epo,:));
    hold on;
    M = SSW.markers{epo}.nsamp;
    for i = 1:size(M,1) 
        points = M(i,1):M(i,2); 
        plot(fake_EEG.time(points),SSW.filtered_signals(epo,points),'-r');
    end
    xlabel('time (sec)'); title('Sleep Slow Wave (SSW) DETECTION (ON THE DELTA BAND)');
    
figure('position',[100 100 1200 400]); 
    subplot(2,1,1); plot(fake_EEG.time,fake_EEG.data(epo,:));
    subplot(2,1,2); plot(fake_EEG.time,Spindles.signals.data_f_sigma(epo,:));
    hold on;
    M = Spindles.markers{epo}.nsamp;
    for i = 1:size(M,1) 
        points = M(i,1):M(i,2); 
        plot(fake_EEG.time(points),Spindles.signals.data_f_sigma(epo,points),'-r');
    end
    xlabel('time (sec)'); title('SPINDLE DETECTION (ON THE SIGMA BAND)');
    