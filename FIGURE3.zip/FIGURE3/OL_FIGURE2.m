function OL_FIGURE2()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  FIGURE 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; clc
addpath(genpath('./scottclowe-superbar-ce333a9/')); 
%addpath(genpath('./errorbarxy'));

% MIXTURE OF GAUSSIANS:
load('./Archive_046','Arch046');
% DATA: 29 Young (g=1), 30 older (g=2), s : index of the subject in the
% group
% Arch046{i}.group{j}.Derivation.frequ_sep{g} : frequency separation (Hz)
%                               .samp{g} : sampled frequencies (150 values)  
%                               .g1{g}{s} : 1st gaussian shape (150 values)
%                               .p1{g}{s} : proba for 1st gaussian
%                               .g2{g}{s} : 2nd gaussian shape (150 values)
%                               .p2{g}{s} : proba for 2nd gaussian
%                               .m1{g}{s} : mean of the 1st gaussian
%                               .m2{g}{s} : mean of the 2nd gaussian
%                               .s1{g}{s} : sigma of the 1st gaussian
%                               .s2{g}{s} : sigma of the 2nd gaussian
%                               .aic{g}{s} : AIC criterion 
 
CFAS = [19 41 78]/256;
C    = {[67 180 180]/256, [1 0 0]};
CE   = {'k' 'k'};
%
u = {2 6 10};
v = {3 7 11};
k = {4 8 12};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('position',[10 10 1100 600]);%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for e = 1:3 %loop over the three groups of electrodes (F,C,P)
    
    gr = 2; % YOUNG  
      
    Der        = Arch046{e}.group{gr}.Derivation;
    separation = Arch046{e}.group{gr}.Separation;
    
    % left
    subplot(3,4,u{e}); ax =gca; set(ax,'color','none'); set(ax,'Fontsize',14);
        hold on
        for isuj = 1:numel(Der.samp{gr})
        plot(Der.samp{gr}{isuj},Der.g1{gr}{isuj},'-','color',C{1});
        end
        for isuj = 1:numel(Der.samp{gr})
        plot(Der.samp{gr}{isuj},Der.g2{gr}{isuj},'-','color',CFAS);
        end
        plot([separation separation],[0 2.7],'--k','linewidth',2);
        tt = sprintf('%2.1f Hz',separation);
        text(separation+0.1,2.5,tt,'fontsize',14);
        if u{e}==2, text(1.5,3.6,'(B) YOUNG','HorizontalAlignment','center','fontsize',16); end
        if u{e}==10, xlabel('transition frequency f_{\tau}  (Hz)'); end 
        xlim([0 3]);
        ylim([0 3]);
        hold off
    
    gr = 1; % OLDER

    Der        = Arch046{e}.group{gr}.Derivation;
    separation = Arch046{e}.group{gr}.Separation;
    
    % Middle 
    subplot(3,4,v{e}); ax =gca; set(ax,'color','none'); set(ax,'Fontsize',14);
    hold on
        for isuj = 1:numel(Der.samp{gr})
        plot(Der.samp{gr}{isuj},Der.g1{gr}{isuj},'-','color',C{1});
        end
        for isuj = 1:numel(Der.samp{gr})
        plot(Der.samp{gr}{isuj},Der.g2{gr}{isuj},'-','color',CFAS);
        end 
        plot([separation separation],[0 2.7],'--k','linewidth',2)
        tt = sprintf('%2.1f Hz',separation);
        text(separation+0.1,2.5,tt,'fontsize',14);
        if v{e}==3, text(1.5,3.6,'(C) OLDER','HorizontalAlignment','center','fontsize',16); end 
        if v{e}==11, xlabel('transition frequency f_{\tau}  (Hz)'); end 
        xlim([0 3]);
        ylim([0 3]);
        hold off
    
    % Right (the third column)
    M = Arch046{e}.M_and_V.M;
    V = Arch046{e}.M_and_V.V;
    P = Arch046{e}.M_and_V.P;

    subplot(3,4,k{e}); ax =gca; set(ax,'color','none'); set(ax,'Fontsize',14);
    superbar(M,'E',V,'P',P,'BarWidth', 0.3,'BarFaceColor', C, 'BarEdgeColor', CE); hold on; plot([0.5 2.5],[0.5 0.5],'--k');
    ax.XTick = [1 2]; ax.XTickLabel = {'YOUNG' 'OLDER'}; 
    ylim([0 1])
    if k{e} == 4, text(1.5,1.2,'(D) Slow Switcher Probability','HorizontalAlignment','center','fontsize',16); end
end



% LEFT COLUMN: the SW densities
load('./Archive_034.mat','Arch034');
cc = [1 5 9];
CC = [255, 1, 59 ; 107, 8, 49]/256;

for i = 1:3
    subplot(3,4,cc(i)); ax =gca; set(ax,'color','none'); set(ax,'Fontsize',14);
    M = [Arch034.nOLy(i) Arch034.nOLm(i)];
    V = [Arch034.sOLy(i) Arch034.sOLm(i)];
    superbar(M,'E',V,'P',P,'BarWidth', 0.4,'BarFaceColor', CC, 'BarEdgeColor', CE);
    ylim([0 14]); ax.XTick = [1 2]; ax.XTickLabel = {'YOUNG' 'OLDER'};
    txt = sprintf('%s\n(mn^{-1})',Arch034.liste{i});
    ylabel(txt);
    if cc(i)==1, text(1.5,17,'(A) Slow Wave Densities','HorizontalAlignment','center','fontsize',16); end
end
end



