
function OL_FIGURE1()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  FIGURE 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; clc
% DATA: 
% X: frequency of SW, for all SW, all subjects
% Y: transition frequency of SW, for all SW, all subjects
% groups: group label for all SW ('YOUNG' or 'OLDER') 
        

% FIGURE:
ff = figure('position',[10 10 900 400]);
% RIGHT SIDE
p2 = uipanel('parent',ff,'position',[0.5 0.01 0.5 0.98],'BackgroundColor','white');
% Color set-up
CY = [255, 1, 59]/256;
CO = [107, 8, 49]/256;
load('./frequenciesOL_YOUNG_OLD','X','Y','groups');    
	my_scatterhist(X,Y,'Group',groups', ...
                       'Nbins',60,...
                       'kernel','on',...
                       'linestyle',{'-' '-'},...
                       'Marker','.','MarkerSize',1,...
                       'Legend','off','Color',[CY;CO],'parent',p2); 
    hold on; set(gca,'Color','none');
    xlim([0 4]); ylim([0 4]);
    xlabel('frequency   (Hz)','FontSize',16);
    ylabel('transition frequency  f_{\tau}   (Hz)','FontSize',16);
    annotation(p2,'line',[0.0269058295964126 0.244394618834081],...
    [0.509309278350515 0.509309278350515],'LineWidth',2,'LineStyle',':'); hold off
    annotation(p2,'textbox',...
    [0.0695067264573991 0.503768041237113 0.0672645739910314 0.0625],...
    'String',{'1.2 Hz'},...
    'LineStyle','none',...
    'FontSize',14,...
    'FitBoxToText','off');
     title('(B)','FontSize',16)
     hold off
        

% LEFT SIDE       
p1 = uipanel('parent',ff,'position',[0.1 0.1 0.3 0.78],'BackgroundColor','white');
load('./Archive_exemple','temps','OL2','tH','tD')
CMAUDE = [10 10 10]/256;
BEURK = [245 3 252]/256;

axes('parent',p1);
hold on
plot(temps, OL2,'linewidth',2,'color',CMAUDE);
plot(temps(tH:tD), OL2(tH:tD),'linewidth',4,'color',BEURK);
plot(temps(1),OL2(1),'.k',    'markersize',18);
plot(temps(end),OL2(end),'.k','markersize',18);
plot(temps(tH),OL2(tH),'.k',  'markersize',30);
plot(temps(tD),OL2(tD),'.k',  'markersize',30);

annotation(p1,'doublearrow',[0.135338345864662 0.766917293233083],...
                            [0.229519480519482 0.229519480519482]);

text(temps(1),OL2(1)+0.06,'(-3\pi/2)','fontsize',20,'HorizontalAlignment','Center');
text(temps(end)+0.03,OL2(end),'(+\pi/2)','fontsize',20);
text(temps(tH),OL2(tH)-0.06,'H (-\pi)','fontsize',18);
text(temps(tD),OL2(tD)-0.09,'D (0)','fontsize',18,'HorizontalAlignment','Center');
title('(A) Phase of the Slow Wave','FontSize',16)
axis off;

aa = [0.236842105263158 0.548872180451128];
bb = [0.531467532467533 0.532467532467533];
annotation(p1,'doublearrow',[0.236842105263158 0.548872180451128],...
     [0.531467532467533 0.532467532467533]);

xx = 0.5*(temps(tH)+temps(tD));
yy = OL2(end)+0.02;
tau = sprintf('\tau');
text(xx,yy,'\tau','fontsize',22);
text(xx+0.025,yy-0.33,'T','fontsize',22);
hold off
end

