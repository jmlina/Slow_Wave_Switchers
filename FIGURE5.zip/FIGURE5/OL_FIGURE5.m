function OL_FIGURE5()
clear
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   FIGURE 5                  %
% Homeostasy of the SWITCHERS %
% detected on the frontal     %
% electrodes                  %
load('./Archive048','X')      %
%                             %
% X is a structure:           %  
%    .SLOW: {old}  {young}    %
%    .FAST: {old}  {young}    %
%                             %
% X.SLOW{gr}{suj} gives the   %
% proportion of SLOW swit. in %
% the cycles of the subject.  %
%                             %
%                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fig = figure('position',[10 100 900 300]);



deriv  = 'FRONTAL';
GROUPE = {'OLD' 'YOUNG'};
ColTYP = {[67 180 180]/256  [19 41 78]/256};
ColAGE = {[107 8 49]/256    [255 1 59]/256};
TypAGE = {'.' 'x'};
TypTYP = {'.' 'x'};
Cy     = 5;


% 2 2 1 : YOUNG (SLOW and FAST) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gr = 2;
subplot(2,9,[1 2 3 4 10 11 12 13]); set(gca,'Color','none'); hold on 

% FAST: average / std error
     U = X.FAST{gr}; 
     MaxCy = 0;
    for cy = 1:8, P{cy} = []; end
    for suj = 1:numel(U)
        MaxCy = max(MaxCy,numel(U{suj}));
        for cy = 1:numel(U{suj})
            P{cy} = [P{cy} U{suj}(cy)];
        end
    end
    for cy = 1:MaxCy; P{cy}(isnan(P{cy}))=[]; end
    MaxCy = min(MaxCy,Cy);
    clear M; for cy = 1:MaxCy, M(cy) = mean(P{cy}); end
    clear E; for cy = 1:MaxCy, E(cy) = 1.96 * std(P{cy}) / sqrt(numel(P{cy})) ; end 
    xx = 1:0.05:MaxCy ; yy = spline(1:MaxCy,M,xx);
    % results for the YOUNG, FAST:
    MaxCy_YF = MaxCy;  M_YF = M; E_YF = E; xx_YF = xx; yy_YF = yy;
    
% SLOW: average / std error
    U = X.SLOW{gr}; 
    MaxCy = 0;
    for cy = 1:8, P{cy} = []; end
    for suj = 1:numel(U)
        MaxCy = max(MaxCy,numel(U{suj}));
        for cy = 1:numel(U{suj})
            P{cy} = [P{cy} U{suj}(cy)];
        end
    end
    for cy = 1:MaxCy; P{cy}(isnan(P{cy}))=[]; end
    MaxCy = min(MaxCy,Cy);

    clear M; for cy = 1:MaxCy, M(cy) = mean(P{cy}); end
    clear E; for cy = 1:MaxCy, E(cy) = 1.96 * std(P{cy}) / sqrt(numel(P{cy})) ; end 
    xx = 1:0.05:MaxCy ; yy = spline(1:MaxCy,M,xx);
    % results for the YOUNG, SLOW:
    MaxCy_YS = MaxCy;  M_YS = M; E_YS = E; xx_YS = xx; yy_YS = yy;

% GRAPHIC (YOUNG)  
plot(xx,yy,':','color',ColTYP{1},'linewidth',3);
xx3 = find(xx>3.1,1,'first'); plot(xx(1:xx3),yy(1:xx3),'-','color',ColTYP{1},'linewidth',3);
plot(1:MaxCy,M,'.','color',ColTYP{1},'markersize',26);
for j=1:MaxCy, errorbar(j,M(j),E(j),'color',ColTYP{1},'linewidth',2); end

plot(xx_YF,yy_YF,':','color',ColTYP{2},'linewidth',3);
xx3 = find(xx_YF>3.1,1,'first'); plot(xx_YF(1:xx3),yy_YF(1:xx3),'-','color',ColTYP{2},'linewidth',3);
plot(1:MaxCy,M_YF,'.','color',ColTYP{2},'markersize',26);
for j=1:MaxCy, errorbar(j,M_YF(j),E_YF(j),'color',ColTYP{2},'linewidth',2); end

xlim([0.5 Cy+0.5]); ax = gca;
ax.XTick = 1:Cy; for j=1:Cy, ax.XTickLabel{j} = num2str(j); end
ylim([0 60]); xlabel('Cycles','fontsize',14); ylabel('percentage','fontsize',14);
text(3.5,50,['(A) YOUNG'] ,'fontsize',20);
ttt = sprintf('fast\nswitchers');
text(1.65,55,ttt,'HorizontalAlignment','center','fontsize',14,'color', ColTYP{2});
ttt = sprintf('slow\nswitchers');
text(2.77,27,ttt,'HorizontalAlignment','center','fontsize',14,'color', ColTYP{1});
text(1,38,'*','HorizontalAlignment','center','fontsize',20);
text(2,12,'*','HorizontalAlignment','center','fontsize',20);
hold off

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % EXPONETIAL REGRESSION (facultative)
        SLOWYOUNG =[1:3;M(1:3)];
        FASTYOUNG =[1:3;M_YF(1:3)];

        x = SLOWYOUNG(1,:)';
        y = SLOWYOUNG(2,:)';
        g = fittype('a-b*exp(-c*x)');
        [f0,gof] = fit(x,y,g,'StartPoint',[[ones(size(x)), -exp(-x)]\y;1]);
        fprintf('\n\t-YOUNG, SLOW Switchers exponential decrease:')
        fprintf('\n\t ''a+b*exp(-c*x)'' with c = %4.2f',f0.c);
        fprintf(' and b = %4.2f (gof=%3.1f)',-f0.b,gof.rsquare);
      
        x = FASTYOUNG(1,:)';
        y = FASTYOUNG(2,:)';
        g = fittype('a-b*exp(-c*x)');
        [f0,gof] = fit(x,y,g,'StartPoint',[[ones(size(x)), -exp(-x)]\y;1]);
        fprintf('\n\t-YOUNG, FAST Switchers exponential decrease:')
        fprintf('\n\t ''a+b*exp(-c*x)'' with c = %4.2f',f0.c);
        fprintf(' and b = %4.2f (gof=%3.1f)',-f0.b,gof.rsquare);
        fprintf('\n\n');
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% 2 2 2 : OLD (SLOW and FAST) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gr = 1;
subplot(2,9,[6 7 8 9 15 16 17 18 ]); set(gca,'Color','none'); hold on

% FAST: average / std error
     U = X.FAST{gr}; 
     MaxCy = 0;
    for cy = 1:8, P{cy} = []; end
    for suj = 1:numel(U)
        MaxCy = max(MaxCy,numel(U{suj}));
        for cy = 1:numel(U{suj})
            P{cy} = [P{cy} U{suj}(cy)];
        end
    end
    for cy = 1:MaxCy; P{cy}(isnan(P{cy}))=[]; end
    MaxCy = min(MaxCy,Cy);
    clear M; for cy = 1:MaxCy, M(cy) = mean(P{cy}); end
    clear E; for cy = 1:MaxCy, E(cy) = 1.96 * std(P{cy}) / sqrt(numel(P{cy})) ; end 
    xx = 1:0.05:MaxCy ; yy = spline(1:MaxCy,M,xx);
    % results for the OLDER, FAST:
    MaxCy_OF = MaxCy;  M_OF = M; E_OF = E; xx_OF = xx; yy_OF = yy;
    
% SLOW: average / std error
    U = X.SLOW{gr}; 
    MaxCy = 0;
    for cy = 1:8, P{cy} = []; end
    for suj = 1:numel(U)
        MaxCy = max(MaxCy,numel(U{suj}));
        for cy = 1:numel(U{suj})
            P{cy} = [P{cy} U{suj}(cy)];
        end
    end
    for cy = 1:MaxCy; P{cy}(isnan(P{cy}))=[]; end
    MaxCy = min(MaxCy,Cy);

    clear M; for cy = 1:MaxCy, M(cy) = mean(P{cy}); end
    clear E; for cy = 1:MaxCy, E(cy) = 1.96 * std(P{cy}) / sqrt(numel(P{cy})) ; end 
    xx = 1:0.05:MaxCy ; yy = spline(1:MaxCy,M,xx);
        % results for the OLDER, SLOW:
    MaxCy_OS = MaxCy;  M_OS = M; E_OS = E; xx_OS = xx; yy_OS = yy;
    
% GRAPHIC (OLDER) 
plot(xx,yy,':','color',ColTYP{1},'linewidth',3);
xx3 = find(xx>3.1,1,'first'); plot(xx(1:xx3),yy(1:xx3),'-','color',ColTYP{1},'linewidth',3);
plot(1:MaxCy,M,'.','color',ColTYP{1},'markersize',26);
for j=1:MaxCy, errorbar(j,M(j),E(j),'color',ColTYP{1},'linewidth',2); end

plot(xx_OF,yy_OF,':','color',ColTYP{2},'linewidth',3);
xx3 = find(xx_OF>3.1,1,'first'); plot(xx_OF(1:xx3),yy_OF(1:xx3),'-','color',ColTYP{2},'linewidth',3);
plot(1:MaxCy,M_OF,'.','color',ColTYP{2},'markersize',26);
for j=1:MaxCy, errorbar(j,M_OF(j),E_OF(j),'color',ColTYP{2},'linewidth',2); end

xlim([0.5 Cy+0.5]); ax = gca;
ax.XTick = 1:Cy; for j=1:Cy, ax.XTickLabel{j} = num2str(j); end
ylim([0 60]); xlabel('Cycles','fontsize',14); ylabel('percentage','fontsize',14);
text(3.5,50,['(B) OLDER'],'fontsize',20);
ttt = sprintf('fast\nswitchers');
text(1.55,50,ttt,'HorizontalAlignment','center','fontsize',14,'color', ColTYP{2});
ttt = sprintf('slow\nswitchers');
text(2.77,32,ttt,'HorizontalAlignment','center','fontsize',14,'color', ColTYP{1});
text(1,28,'*','HorizontalAlignment','center','fontsize',20);
text(2,18,'*','HorizontalAlignment','center','fontsize',20);
hold off

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % EXPONETIAL REGRESSION (facultative)
        SLOWOLD =[1:3;M(1:3)];
        FASTOLD =[1:3;M_OF(1:3)];

        x = SLOWOLD(1,:)';
        y = SLOWOLD(2,:)';
        g = fittype('a-b*exp(c*x)');
        [f0,gof] = fit(x,y,g,'StartPoint',[[ones(size(x)), -exp(x)]\y;1]);
        fprintf('\n\t-OLDER, SLOW Switchers exponential decrease:')
        fprintf('\n\t ''a+b*exp(-c*x)'' with c = %4.2f',f0.c);
        fprintf(' and b = %4.2f (gof=%3.1f)',-f0.b,gof.rsquare);
        
        x = FASTOLD(1,:)';
        y = FASTOLD(2,:)';
        g = fittype('a-b*exp(-c*x)');
        [f0,gof] = fit(x,y,g,'StartPoint',[[ones(size(x)), -exp(-x)]\y;1]);
        fprintf('\n\t-OLDER, FASTSwitchers exponential reduction:')
        fprintf('\n\t ''a+b*exp(-c*x)'' with c = %4.2f',-f0.c);
        fprintf(' and b = %4.2f (gof=%3.1f)',-f0.b,gof.rsquare);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('\n\n');
end
 
