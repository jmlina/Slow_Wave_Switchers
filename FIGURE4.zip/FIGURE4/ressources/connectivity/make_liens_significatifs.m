function A = make_liens_significatifs(stat,seuil)
% stat.paire: cell des paires d'electrodes
% stat.value: table des valeurs de la stat dans l'ordre des paires
% -- output:
% A.paires_gardees: indice des paires significatives

ll = find(abs(stat.value)> seuil);


        A.frequency           = 0.0;
        A.frequencies         = [0 0];
        A.all_paires          = stat.paire;
        A.paires_gardees      = ll;
        A.nombre_significatif = length(A.paires_gardees);
        A.contraste           = ones(1,A.nombre_significatif);
        A.Z_paires_sign       = ones(1,A.nombre_significatif);

end