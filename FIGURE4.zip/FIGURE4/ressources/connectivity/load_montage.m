
function EEG = load_montage()
    load electrodesEEG;
    EEG.liste = {}; 
    for i=1:length(c), EEG.liste{i} = c(i).name; end
    EEG.c = c;
end