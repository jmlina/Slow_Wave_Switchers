function [ CofG ] = compute_C_of_Graph( A,c,ifr,electr )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    Afr = A{ifr};
    [ TAB ] = do_table_liens( Afr, electr );
    C = 0; %L = 0; 
    for i=1:size(TAB,2)
        dep = TAB(1,i); arr = TAB(2,i); Lx = c(arr).posy - c(dep).posx; Ly = c(arr).posy - c(dep).posy; 
        %C = C + sqrt(Lx^2+Ly^2)*A{ifr}.Z_paires_sign(i); 
        %L = L + sqrt(Lx^2+Ly^2);
        C = C + A{ifr}.Z_paires_sign(i);
    end
    
    %CofG = C/L;
    CofG = C;%/size(TAB,2);

end

