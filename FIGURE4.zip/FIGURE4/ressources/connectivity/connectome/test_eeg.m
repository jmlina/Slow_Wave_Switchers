

clear;
clc
load electrodesEEG_maude
%load exemple_matrice_connectivite

% On construit ici le tableau des liens: TAB
% 1ere ligne: noeud de depart
% 2ieme ligne: noeud d'arrivée
% 3 ieme ligne : 0 ou 1 (0=significatif, 1= au dela d'un seuil). Ici,
% random.

TF = zeros(1,20*21/2); TF(unique(randi(20*21/2,1,100))) = 1;

TAB = [];
k = 1; for i =1:20, for j=1:i, TAB(1,k)=i; TAB(2,k)=j; TAB(3,k) = randi(2)-1; k = k+1; end; end; 
liste_liens = find(TF); TAB = TAB(:,liste_liens);
% on enleve les liens louches (diagonale??)
keep = ones(1,size(TAB,2));
for j=1:size(TAB,2), if(TAB(1,j)==TAB(2,j)), keep(j) = 0; end; end
TAB = TAB(:,keep==1);




% fonction principale:
f1 = plot_connectome_on_EEG(c,TAB);

% % Si on attribue une valeur d'energie a chaque patch (en fait un pourcentage entre 0 et 1, la somme donne 1)
% ENE = rand(1,88); ENE = ENE /sum(ENE);
% 
% % fonction principale:
% plot_connectome_on_eeg(LAYOUT,TAB,ENE)