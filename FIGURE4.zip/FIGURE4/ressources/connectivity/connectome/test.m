

clear;
clc
load LAYOUT
load exemple_matrice_connectivite

% On construit ici le tableau des liens: TAB
% 1ere ligne: noeud de depart
% 2ieme ligne: noeud d'arrivée
% 3 ieme ligne : 0 ou 1 (0=significatif, 1= au dela d'un seuil). Ici,
% random.

k = 1; for i =1:88, for j=1:i, TAB(1,k)=i; TAB(2,k)=j; TAB(3,k) = randi(2)-1; k = k+1; end; end; 
liste_liens = find(TF); TAB = TAB(:,liste_liens);
% on enleve les liens louches (diagonale??)
if(TAB(1,1)==TAB(2,1)), TAB = TAB(:,2:end); end
    for i=2:size(TAB,2)-1, if(TAB(1,i)==TAB(2,i)), TAB = [TAB(:,1:i-1) TAB(:,i+1:end)]; end; end
if(TAB(1,end)==TAB(2,end)), TAB = TAB(:,1:end-1); end;

% fonction principale:
plot_connectome(LAYOUT,TAB)

% Si on attribue une valeur d'energie a chaque patch (en fait un pourcentage entre 0 et 1, la somme donne 1)
ENE = rand(1,88); ENE = ENE /sum(ENE);

% fonction principale:
plot_connectome(LAYOUT,TAB,ENE)