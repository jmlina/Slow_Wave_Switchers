function x = XYlam(p)
l = 0:0.1:1;
n = length(p);
x = p(1)*(1-l).^(n-1);
for i = 1:n-1
	x = x+nchoosek(n-1,i)*p(1+i)*(1-l).^(n-1-i).*l.^(i);
end