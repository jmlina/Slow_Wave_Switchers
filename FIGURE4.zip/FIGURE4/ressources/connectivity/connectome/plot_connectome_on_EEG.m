function [fig] = plot_connectome_on_EEG(LAYOUT,Tableau_des_liens,varargin)

% the LAYOUT data gives the set of electrodes with 2D location and name
list_of_names = {LAYOUT(:).name};
Nbr_of_electr = length(list_of_names);
fig = figure; 
for i=1:Nbr_of_electr; plot(LAYOUT(i).posx,LAYOUT(i).posy,'.'); 
                       text(LAYOUT(i).posx,LAYOUT(i).posy,LAYOUT(i).name,'FontSize',12,'Color',[0.5 0.5 0.5]); hold on; 
end; 
axis square; axis off
 
% TRACAGE DES LIENS
if ~isempty(Tableau_des_liens)
    % code de couleurs: liens fort en rouge (les autres en bleu)
    forces{1} = [0.0 0.0 1.0]; ligne{1} = 1;
    forces{2} = [1.0 0.0 0.0]; ligne{2} = 2;

    hold on
    for i = 1:size(Tableau_des_liens,2)
        elect_d = Tableau_des_liens(1,i);
        elect_f = Tableau_des_liens(2,i);
        force_du_lien = Tableau_des_liens(3,i)+1;
        deb = LAYOUT(elect_d);
        fin = LAYOUT(elect_f);                 

                  px = deb.posx;
                  py = deb.posy;

                  qx = fin.posx;
                  qy = fin.posy;
    
        ax = [px max((px+qx)/5,0.05) qx];
        ay = [py max((py+qy)/5,0.05) qy];
        sx = XYlam(ax);
        sy = XYlam(ay);
        plot(sx,sy,'-','linewidth',ligne{force_du_lien},'Color',forces{force_du_lien}); pause(0.001);
    end;
    electrodes_impliquees = unique([Tableau_des_liens(1,:) Tableau_des_liens(2,:)]);
    for i=1:length(electrodes_impliquees) 
        text(LAYOUT(electrodes_impliquees(i)).posx,LAYOUT(electrodes_impliquees(i)).posy,LAYOUT(electrodes_impliquees(i)).name,'FontSize',12,'Color',[0 0 0]); 
    end;
    hold off
end
end