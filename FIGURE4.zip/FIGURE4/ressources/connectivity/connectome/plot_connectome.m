function [] = plot_connectome(LAYOUT,Tableau_des_liens,varargin)


% decomposition du LAYOUT de Mazoyer:
left_lobes  = fields(LAYOUT.left);
right_lobes = fields(LAYOUT.right);

% les patches presentes (gauche)
N_left_patch = 0;
N_left_lobes = length(left_lobes);
for i = 1:N_left_lobes
    L(i).regions = getfield(LAYOUT.left,left_lobes{i});
    L(i).name = left_lobes{i};
    L(i).index_in_scout = [];
    L(i).X = [];
    L(i).Y = [];
    N_left_patch = N_left_patch + length(fields(L(i).regions));
end
% (droite)
N_right_patch = 0;
N_right_lobes = length(right_lobes);
for i = 1:N_right_lobes
    R(i).regions = getfield(LAYOUT.right,right_lobes{i});
    R(i).name = right_lobes{i};
    R(i).index_in_scout = [];
    R(i).X = [];
    R(i).Y = [];
    N_right_patch = N_right_patch + length(fields(R(i).regions));
end

% points sur le cercles
NL = N_left_patch  + N_left_lobes;
NR = N_right_patch + N_right_lobes;
XL = cos(pi*(0.5+(1:NL)/(NL+1)));
YL = sin(pi*(0.5+(1:NL)/(NL+1)));
XR = cos(pi*(0.5-(1:NR)/(NR+1)));
YR = sin(pi*(0.5-(1:NR)/(NR+1)));

% affectation patches -> position et nom des regions
N_patch = N_right_patch + N_left_patch;
LUT_patches = zeros(5,N_patch);
%(gauche)
k = 1;
 for i=1:length(L)
     liste = fields(L(i).regions);
     for j=1:length(liste)
        u = getfield(L(i).regions,liste{j});
        L(i).index_in_scout = [L(i).index_in_scout u.IdInScoutStructure];
        L(i).X = [L(i).X XL(k)];
        L(i).Y = [L(i).Y YL(k)];
        k = k+1;
     end
     LUT_patches(1,L(i).index_in_scout) = 1;
     LUT_patches(2,L(i).index_in_scout) = i;
     LUT_patches(3,L(i).index_in_scout) = mean([L(i).X]);
     LUT_patches(4,L(i).index_in_scout) = mean([L(i).Y]);
     L(i).nameX = 1.2*mean([L(i).X])*sqrt(mean([L(i).X])^2+mean([L(i).Y])^2);
     L(i).nameY = 1.2*mean([L(i).Y])*sqrt(mean([L(i).X])^2+mean([L(i).Y])^2);
     L(i).nameA = 180*angle(L(i).nameX+1j*L(i).nameY)/pi - 90;
     k = k+1;
 end
 % (droit)
 k = 1;
 for i=1:length(R)
     liste = fields(R(i).regions);
     for j=1:length(liste)
        u = getfield(R(i).regions,liste{j});
        R(i).index_in_scout = [R(i).index_in_scout u.IdInScoutStructure];
        R(i).X = [R(i).X XR(k)];
        R(i).Y = [R(i).Y YR(k)];
        k = k+1;
     end
     LUT_patches(1,R(i).index_in_scout) = 2;
     LUT_patches(2,R(i).index_in_scout) = i;
     LUT_patches(3,R(i).index_in_scout) = mean([R(i).X]);
     LUT_patches(4,R(i).index_in_scout) = mean([R(i).Y]);
     R(i).nameX = 1.2*mean([R(i).X])*sqrt(mean([R(i).X])^2+mean([R(i).Y])^2);
     R(i).nameY = 1.2*mean([R(i).Y])*sqrt(mean([R(i).X])^2+mean([R(i).Y])^2);
     R(i).nameA = 180*angle(R(i).nameX+1j*R(i).nameY)/pi - 90;
     k = k+1;
 end

% creation de la figure:
Parent1 = figure('position',[200 200 800 800]);
axes1 = axes('Parent',Parent1,'YTick',zeros(1,0),'XTick',zeros(1,0),...
             'PlotBoxAspectRatio',[1 1 1]);
xlim(axes1,[-1.3 1.3]);
ylim(axes1,[-1.3 1.3]);
box(axes1,'on');
hold(axes1,'all');


% TRACAGE DES LIENS

% code de couleurs: liens fort en rouge (les autres en gris)
forces{1} = [0.5 0.5 0.5]; ligne{1} = 2;
forces{2} = [1.0 0.0 0.0]; ligne{2} = 4;

hold on
for i = 1:size(Tableau_des_liens,2)
    patch_d = Tableau_des_liens(1,i);
    patch_f = Tableau_des_liens(2,i);
    force_du_lien = Tableau_des_liens(3,i)+1;
    deb = LUT_patches(:,patch_d);
    fin = LUT_patches(:,patch_f);                 
    dx = deb(3);
    dy = deb(4);
    if deb(1)==1, p1 = find(patch_d==L(deb(2)).index_in_scout);
                  px = L(deb(2)).X(p1);
                  py = L(deb(2)).Y(p1);
    end;
    if deb(1)==2, p1 = find(patch_d==R(deb(2)).index_in_scout);
                  px = R(deb(2)).X(p1);
                  py = R(deb(2)).Y(p1);
    end;
    fx = fin(3);
    fy = fin(4);
    if fin(1)==1, p1 = find(patch_f==L(fin(2)).index_in_scout);
                  qx = L(fin(2)).X(p1);
                  qy = L(fin(2)).Y(p1);
    end;
    if fin(1)==2, p1 = find(patch_f==R(fin(2)).index_in_scout);
                  qx = R(fin(2)).X(p1);
                  qy = R(fin(2)).Y(p1);
    
    ax = [px max((dx+fx)/4,0.25) qx];
	ay = [py max((dy+fy)/4,0.25) qy];
    sx = XYlam(ax);
    sy = XYlam(ay);
    plot(sx,sy,'-','linewidth',ligne{force_du_lien},'Color',forces{force_du_lien}); pause(0.001);
    end;
    
end

% les regions sur la figure (gauche):
if nargin < 3
    K = colormap('jet');
    for i=1:length(L)
        plot([L(i).X],[L(i).Y],'Marker','o','MarkerSize',8, ...
            'LineStyle','none','MarkerEdgeColor','k', ...
            'MarkerFaceColor', 'k','Color',[0 0 1]);
        text(L(i).nameX,L(i).nameY,L(i).name,'HorizontalAlignment','center',...
        'rotation',L(i).nameA,'fontsize',16,'FontWeight','normal');
    end
    % droit:
    for i=1:length(R)
        plot([R(i).X],[R(i).Y],'Marker','o','MarkerSize',8, ...
            'LineStyle','none','MarkerEdgeColor','k', ...
            'MarkerFaceColor', 'k','Color',[0 0 1]);
        text(R(i).nameX,R(i).nameY,R(i).name,'HorizontalAlignment','center',...
        'rotation',R(i).nameA,'fontsize',16,'FontWeight','normal');
    end
    hold off
    axis square; axis off
else
    energie = varargin{1};
    energie = floor(64*(energie-min(energie))/(max(energie)-min(energie)));
    energie(energie==0) = 1;
    K = colormap('jet');
    
    for i=1:length(L)
        for k = 1:length(L(i).X)
            K_energie = K(energie(L(i).index_in_scout(k)),:);
            plot([L(i).X(k)],[L(i).Y(k)],'Marker','o','MarkerSize',8, ...
            'LineStyle','none','MarkerEdgeColor','k', ...
            'MarkerFaceColor', K_energie,'Color',[0 0 1]);
            text(L(i).nameX,L(i).nameY,L(i).name,'HorizontalAlignment','center',...
            'rotation',L(i).nameA,'fontsize',16,'FontWeight','normal');
        end
    end
    % droit:
    for i=1:length(R)
        for k = 1:length(R(i).X)
            K_energie = K(energie(R(i).index_in_scout(k)),:);
            plot([R(i).X(k)],[R(i).Y(k)],'Marker','o','MarkerSize',8, ...
            'LineStyle','none','MarkerEdgeColor','k', ...
            'MarkerFaceColor', K_energie,'Color',[0 0 1]);
            text(R(i).nameX,R(i).nameY,R(i).name,'HorizontalAlignment','center',...
            'rotation',R(i).nameA,'fontsize',16,'FontWeight','normal');
        end
    end
    hold off
end

axis square; axis off
end

