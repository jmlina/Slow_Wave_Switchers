function plot_ax_degree_on_EEG(LAYOUT,Tableau_des_liens,my_figure,k)

% the LAYOUT data gives the set of electrodes with 2D location and name
list_of_names = {LAYOUT(:).name};
Nbr_of_electr = length(list_of_names);
figure(my_figure.hand);
subplot(my_figure.Nl,my_figure.Nc,k); hold on

for i=1:Nbr_of_electr; plot(LAYOUT(i).posx,LAYOUT(i).posy,'.'); 
                       text(LAYOUT(i).posx,LAYOUT(i).posy,LAYOUT(i).name,'FontSize',12,'Color',[0.5 0.5 0.5]); hold on; 
end; 
axis square; axis off;

degre = zeros(1,Nbr_of_electr); 
for it=1:size(Tableau_des_liens,2)
    if Tableau_des_liens(3,it)
        degre(Tableau_des_liens(1,it))=degre(Tableau_des_liens(1,it))+1; degre(Tableau_des_liens(2,it))=degre(Tableau_des_liens(2,it))+1; 
    else
        degre(Tableau_des_liens(1,it))=degre(Tableau_des_liens(1,it))-1; degre(Tableau_des_liens(2,it))=degre(Tableau_des_liens(2,it))-1;
    end      
end

for i=1:Nbr_of_electr; 
            if abs(degre(i))
                 if (sign(degre(i))==+1)
                     plot([LAYOUT(i).posx],[LAYOUT(i).posy], ...
                    'Marker','o','MarkerSize',2*abs(degre(i)), ...
                    'LineStyle','none','MarkerEdgeColor','r');% , ...
                    %'MarkerFaceColor', 'k','Color',[0 0 1]);
                    hold on
                 else
                     plot([LAYOUT(i).posx],[LAYOUT(i).posy], ...
                    'Marker','o','MarkerSize',2*abs(degre(i)), ...
                    'LineStyle','none','MarkerEdgeColor','b');% , ...
                    hold on
                 end    
            end
            pause(0.001);
            %text(LAYOUT(i).posx,LAYOUT(i).posy,LAYOUT(i).name,'FontSize',10,'Color',[0 0 0]); hold on;       
end; 
% set(gca,'outerposition',[1 1 100 100]); axis square; axis off
 hold off
 
% % TRACAGE DES LIENS
% if ~isempty(Tableau_des_liens)
%     % code de couleurs: liens fort en rouge (les autres en bleu)
%     forces{1} = [0.0 0.0 1.0]; ligne{1} = 1;
%     forces{2} = [1.0 0.0 0.0]; ligne{2} = 2;
% 
%     hold on
%     for i = 1:size(Tableau_des_liens,2)
%         elect_d = Tableau_des_liens(1,i);
%         elect_f = Tableau_des_liens(2,i);
%         force_du_lien = Tableau_des_liens(3,i)+1;
%         deb = LAYOUT(elect_d);
%         fin = LAYOUT(elect_f);                 
% 
%                   px = deb.posx;
%                   py = deb.posy;
% 
%                   qx = fin.posx;
%                   qy = fin.posy;
%     
%         ax = [px max((px+qx)/5,0.05) qx];
%         ay = [py max((py+qy)/5,0.05) qy];
%         sx = XYlam(ax);
%         sy = XYlam(ay);
%         plot(sx,sy,'-','linewidth',ligne{force_du_lien},'Color',forces{force_du_lien}); pause(0.001);
%     end;
%     electrodes_impliquees = unique([Tableau_des_liens(1,:) Tableau_des_liens(2,:)]);
%     for i=1:length(electrodes_impliquees) 
%         text(LAYOUT(electrodes_impliquees(i)).posx,LAYOUT(electrodes_impliquees(i)).posy,LAYOUT(electrodes_impliquees(i)).name,'FontSize',12,'Color',[0 0 0]); 
%     end;
%     hold off
% end
end