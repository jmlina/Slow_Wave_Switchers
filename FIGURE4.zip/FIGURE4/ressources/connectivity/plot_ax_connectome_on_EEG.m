function plot_ax_connectome_on_EEG(LAYOUT,Tableau_des_liens,my_figure,k)

% the LAYOUT data gives the set of electrodes with 2D location and name
list_of_names = {LAYOUT(:).name};
Nbr_of_electr = length(list_of_names);
figure(my_figure.hand);
subplot(my_figure.Nl,my_figure.Nc,k);


FtSz = 16; if isfield(my_figure,'fontsize'), FtSz = my_figure.fontsize; end;


pp = 0;
for i=1:Nbr_of_electr; plot(LAYOUT(i).posx,LAYOUT(i).posy,'.'); pp = min(pp,LAYOUT(i).posx);
                       text(LAYOUT(i).posx,LAYOUT(i).posy,LAYOUT(i).name,'FontSize',12,'Color',[0.5 0.5 0.5]); hold on; 
end;
if isfield(my_figure,'ylabel'), text(1.3*pp,0,my_figure.ylabel,'rotation',90,'HorizontalAlignment','center','fontsize',FtSz); end
axis square; axis off; hold off
 

% CODE DS COULEURS
% range dans my_figure.code_couleurs.positif = forces{2}
% range dans my_figure.code_couleurs.negatif = forces{1}

% TRACAGE DES LIENS
if ~isempty(Tableau_des_liens)
    % code de couleurs: liens fort en rouge (les autres en bleu)
    if isfield(my_figure,'code_couleurs')
           forces{1} = my_figure.code_couleurs.negatif; ligne{1} = 1; % [0.5 1.0 0.5]; ligne{1} = 1;
           forces{2} = my_figure.code_couleurs.positif; ligne{2} = 2; % [1.0 0.5 0.0]; ligne{2} = 2; 
    else
           forces{1} = [0.0 0.0 1.0]; ligne{1} = 1; % [0.5 1.0 0.5]; ligne{1} = 1;
           forces{2} = [1.0 0.0 0.0]; ligne{2} = 2; % [1.0 0.5 0.0]; ligne{2} = 2;
    end

    hold on
    for i = 1:size(Tableau_des_liens,2)
        elect_d = Tableau_des_liens(1,i);
        elect_f = Tableau_des_liens(2,i);
        force_du_lien = Tableau_des_liens(3,i)+1;
        deb = LAYOUT(elect_d);
        fin = LAYOUT(elect_f);                 

                  px = deb.posx;
                  py = deb.posy;

                  qx = fin.posx;
                  qy = fin.posy;
    
        ax = [px max((px+qx)/5,0.05) qx];
        ay = [py max((py+qy)/5,0.05) qy];
        sx = XYlam(ax);
        sy = XYlam(ay);
        plot(sx,sy,'-','linewidth',ligne{force_du_lien},'Color',forces{force_du_lien}); pause(0.001);
    end;
    electrodes_impliquees = unique([Tableau_des_liens(1,:) Tableau_des_liens(2,:)]);
    for i=1:length(electrodes_impliquees) 
        text(LAYOUT(electrodes_impliquees(i)).posx,LAYOUT(electrodes_impliquees(i)).posy,LAYOUT(electrodes_impliquees(i)).name,'FontSize',12,'Color',[0 0 0]); 
    end;
     
    hold off
end

