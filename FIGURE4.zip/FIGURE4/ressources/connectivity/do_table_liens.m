function [ TAB ] = do_table_liens( A, electrodes_maude )

% A est une structure:
%  A ----------- .nombre_significatif  = nombre de liens > seuil
%                .all_paires
%                .paires_gardees
%                .contraste = vecteur de +1 ou -1
%                .frequency

% electrodes_maude contient le montage


TAB = [];

if A.nombre_significatif
    TAB = zeros(3,A.nombre_significatif);

    for k = 1:A.nombre_significatif
        paire  = A.all_paires{A.paires_gardees(k)};
        sep    = strfind(paire,'-');
        noeud1 = paire(1:sep-1);   loc1 = find(strcmpi(electrodes_maude,noeud1));
        noeud2 = paire(sep+1:end); loc2 = find(strcmpi(electrodes_maude,noeud2));
        TAB(1,k) = loc1;
        TAB(2,k) = loc2;
        if A.contraste(k)==1, TAB(3,k) = 1; end
    end
end
end

