function FIGURE3()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            


clc 
addpath(genpath('./ressources/connectivity/')); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CONNECTIVITY OF THE SWITCHERS FOR THE  %
% YOUNG COHORT                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main Figure                                                             %
fig_connectome = figure('position',[200 100 1200 700],'name','FIGURE 3'); %
% features:                                                               %
nodeOL{1} = {'Fast-Switchers^*' '' '' '' '' ''};                          %
nodeOL{2} = {'Slow-Switchers^*' '' '' '' '' ''};                          %
the_figure.hand = fig_connectome;                                         %
the_figure.code_couleurs.positif = [0.3 0.3 0.3];                         %
the_figure.code_couleurs.negatif = [0.0 0.0 1.0];                         %
CMAUDE = [95 95 95 ]/256;                                                 %
BEURK  = [245 3 252]/256;                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% First Archive: PLI over the 5 phases of SLOW WAVES, in the two groups   %
% and template of a Sleep SLOW WAVE                                       %
%                                                                         %
load('./Archive_926','Arch_926');                                         %
% SLOW WAVE: this is a template of a slow wave (time2,OL2)
OL2 = Arch_926.OL2;
time2 = Arch_926.temps;
% timing of the Hyperpolarization and Depolarization
TH = Arch_926.TH; tH = Arch_926.tH;
TD = Arch_926.TD; tD = Arch_926.tD;
%nodeOL = Arch_926.nodeOL;
        
    for k =1:6 % LOOP OVER THE SIX TEMPLATES WITH A SPECIFIC PHASE

        subplot(4,6,k);  ax = gca; set(ax,'Color','none');
        hold on
        plot(time2, OL2,'linewidth',2,'color',CMAUDE);
        plot(time2(tH:tD), OL2(tH:tD),'linewidth',4,'color',BEURK);
        ta = tD;
        uu = find(OL2>0,2,'first'); tc = uu(2);
        tb = round((tc+tH)/2); 
        td = round((tc+tD)/2); 
        te = tH;
        tf = tD + round((tD-tc)/2);

        if k==1, plot(time2(tH), OL2(tH),'.k','markersize',30); 
        else plot(time2(tH), OL2(tH),'.','color',BEURK,'markersize',26); 
        end
        if k==5, plot(time2(tD), OL2(tD),'.k','markersize',30); 
        else plot(time2(tD), OL2(tD),'.','color',BEURK,'markersize',26);
        end
        if k==2, plot(time2(tb), OL2(tb),'.k','markersize',30); end
        if k==3, plot(time2(tc), OL2(tc),'.k','markersize',30); end
        if k==4, plot(time2(td), OL2(td),'.k','markersize',30); end
        if k==6, plot(time2(tf), OL2(tf),'.k','markersize',30); end


        if k==1, text(time2(tH), OL2(tH)-0.1,'a','fontsize',18); end
        if k==2, text(time2(tb)+0.05, OL2(tb),'b','fontsize',18); end
        if k==3, text(time2(tc)+0.05, OL2(tc),'c','fontsize',18); end
        if k==4, text(time2(td)-0.12, OL2(td),'d','fontsize',18); end
        if k==5, text(time2(tD), OL2(tD)-0.1,'e','fontsize',18); end
        if k==6, text(time2(tf), OL2(tf)-0.2,'f','fontsize',18); end
        axis off;                                                         %
        hold off;                                                         %
    end                                                                   %
    pause(0.2);                                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% PLI from the Archive, for the two groups   SLOW SWITCHERS               %
% group = 1 : OLDER                                                       %
% group = 2 : YOUNG                                                       %
% the PLI's are stored in A
A = Arch_926.A; 
%  A{group}{phase}.nombre : link kept in the graph
%                 .all_paires : electrode-electrode pairs
%                 .paires_gardeed : list of significative pairs
%                  (from a non parametric test)
% EEG montage
electrodes = Arch_926.electrodes;
c = Arch_926.c;
%  c(electrode).posx
%              .posy
%              .name  
        gr = 2; % we consider the YOUNG **** SLOW SWITCHERS SLOW WAVES
        for k = 1:6 % LOOP OVER EACH PHASE, plot of the EEG connectome
        Ak = A{gr}{k};
        [ TAB ] = do_table_liens( Ak, electrodes );
        % parameter of the figure of the graph:
        the_figure.Nl = 4;
        the_figure.Nc = 6;
        the_figure.code_couleurs.negatif = [0.45 0.45 0.45];
        the_figure.code_couleurs.positif = [0.45 0.45 0.45];         
        the_figure.ylabel = nodeOL{2}{k};                                 %
        plot_ax_connectome_on_EEG(c,TAB,the_figure,(3-2)*6+k);            %
        end                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PLI from the Archive, for the two groups   FAST SWITCHERS               %
% group = 1 : OLDER                                                       %
% group = 2 : YOUNG                                                       %
% the PLI's are stored in A 
load('./Archive_936','Arch_936');
A = Arch_936.A;         %PLI    = Arch_936.PLI; 
% EEG montage (same as before)
A = Arch_936.A;        
electrodes = Arch_936.electrodes;
c = Arch_936.c;

        gr = 2; % we consider the YOUNG **** FASTSWITCHERS SLOW WAVES
        for k = 1:6 % LOOP OVER EACH PHASE, plot of the EEG connectome
        Ak = A{gr}{k};
        [ TAB ] = do_table_liens( Ak, electrodes );
        % parameter of the figure of the graph:
        the_figure.Nl = 4;
        the_figure.Nc = 6;
        the_figure.code_couleurs.negatif = [0.45 0.45 0.45];
        the_figure.code_couleurs.positif = [0.45 0.45 0.45];
        the_figure.ylabel = nodeOL{1}{k};                                 %
        plot_ax_connectome_on_EEG(c,TAB,the_figure,(3-1)*6+k);            %
        end                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end
